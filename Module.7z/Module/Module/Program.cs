﻿namespace Prakt_3
{
    public class Test
    {
        private int[] num_1;
        private int up;
        private int capacity;

        public Test(int size)
        {
            capacity = size;
            num_1 = new int[capacity];
            up = -1;
        }

        public void Go(int item)
        {
            if (up == capacity - 1)
            {
                Console.WriteLine("В стеку забагато данних");
                return;
            }
            num_1[++up] = item;
        }

        public int Pop()
        {
            if (up == -1)
            {
                Console.WriteLine("Стек на заповнений");
                return -1;
            }
            return num_1[up--];
        }

        public int Peek()
        {
            if (up == -1)
            {
                Console.WriteLine("Стек порожній");
                return -1;
            }
            return num_1[up];
        }
        public bool IsEmpty()
        {
            return up == -1;
        }

        public int Count()
        {
            return up + 1;
        }
    }

    internal class Program
    {


        static void Main(string[] args)
        {
            var Stack = new Stack<int>(10);

            Stack.Push(1);
            Stack.Push(2);
            Stack.Push(3);
            Stack.Push(4);
            Stack.Push(5);
            Stack.Push(6);

            if (Stack.Peek() == null)
            {
                Console.WriteLine("Стек порожній");
            }
            else
            {
                Console.WriteLine("Стек не порожній");
            }
        }
    }
}
